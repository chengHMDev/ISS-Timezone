<?php
include "ISS.php";
class Webservices{
	function getLocation($timestamp){
		$ISSInstance = new ISS();
		$timestamps = $this -> generateTimestamp($timestamp);
		$locations = $ISSInstance->getLocations($timestamps);
		print_r($locations);
		return $locations;
	}
	//generate 13 point timestamp 
	function generateTimestamp($timestamp){
		unset($timestamps);
		$timestamps = [];
		$timestamp = $timestamp - 3600;
		for ($x = 0; $x < 13; $x++) {
			//600 means every 10 minutes
			$timestamp = $timestamp + 600;
			array_push($timestamps,$timestamp);
		}
		return $timestamps;
	}
}
$webservice = new Webservices();
$webservice->getLocation(1436029892);

?>