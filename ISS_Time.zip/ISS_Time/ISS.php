<?php
class ISS {

}
function getConfig(){
	session_start();
	$baseURL = "https://api.wheretheiss.at/v1/satellites/";
	$json = file_get_contents($baseURL);
	$result = json_decode($json, true);
	$satID = $result[0]["id"];
	$URL = $baseURL.$satID;
	var_dump($URL);
}

getConfig();
?>